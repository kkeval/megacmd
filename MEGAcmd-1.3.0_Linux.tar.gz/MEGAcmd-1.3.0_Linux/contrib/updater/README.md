# How to generate update file

To create an update file, you need to pass the list of files for window/macos included
 in this folder to the Update Generator.

The update file includes all the information that the genrator requires
 including version number and base URL.
