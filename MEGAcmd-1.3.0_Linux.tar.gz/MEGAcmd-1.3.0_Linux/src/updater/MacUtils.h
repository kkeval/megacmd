#ifndef MACUTILS_H
#define MACUTILS_H
#include <iostream>

bool downloadFileSynchronously(std::string url, std::string path);

#endif // MACUTILS_H
