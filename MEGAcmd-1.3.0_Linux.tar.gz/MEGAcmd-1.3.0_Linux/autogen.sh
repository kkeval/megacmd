#!/bin/sh
autoreconf -fiv || exit 1;
